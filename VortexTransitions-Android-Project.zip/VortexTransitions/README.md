# VortexTransitions Android prototype

A mobile-first Android WebView app wrapper for the VortexTransitions editing prototype.

## Current features
- Native Android document picker for selecting multiple videos and images.
- Local media previews and a multi-clip timeline UI.
- Effects, transitions, adjustment, keyframe, text, audio and speed panels (prototype controls).
- Export settings UI for 720p, 1080p, 2K, 4K and up to 60 FPS.
- Uses the supplied Vortex spiral logo concept.

## Important limitations
This is an early app prototype, not a finished video editor. The UI can import and preview media, but it does **not** yet render edited videos, encode 4K/60 FPS, or implement the full effect engine. Those require a native media pipeline and substantial development. The export screen currently demonstrates settings only.

## Build with Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder as an existing project.
3. Allow Gradle sync to finish (JDK 17; Gradle 8.9; Android Gradle Plugin 8.7.3).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to your Android phone and open it. Android may ask you to allow installation from that source.

## Build in GitHub Actions (without Android Studio)
1. Create a new GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab.
3. Run **Build VortexTransitions APK** (or push to `main`).
4. When the workflow finishes, open the run and download the `VortexTransitions-debug-apk` artifact.
5. Extract the ZIP on your phone and install `app-debug.apk`.

The GitHub workflow builds a debug APK for personal testing. It is not a Play Store release build.
